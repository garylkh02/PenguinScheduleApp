package com.example.finalpro.penguinsch

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.*

@Entity
data class Schedule(
    @PrimaryKey
    var id: UUID = UUID.randomUUID(),
    var title: String = "",
    var date: Date = Date(),
    var time: Date = Date(),
    var isSolved: Boolean = false,
    var partner: String = "",
    var description: String = "",
    var isPriority: Boolean = false
)
