package com.example.finalpro.penguinsch

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ScheduleListViewModel : ViewModel() {
    private val scheduleRepository = ScheduleRepository.get()
    val allTasks: LiveData<List<Schedule>> = scheduleRepository.getSchedules()
    private val _filteredTasks = MutableLiveData<List<Schedule>>()
    val taskListLiveData: LiveData<List<Schedule>>
        get() = scheduleRepository.getSchedules()
    val filteredTasks: LiveData<List<Schedule>>
        get() = _filteredTasks

    init {
        _filteredTasks.value = emptyList()
        allTasks.observeForever { tasks ->
            filterTasks(_filteredTasks.value.orEmpty().toString())
        }
    }

    fun filterTasks(query: String) : List<Schedule> {
        val filteredList = if (query.isBlank()) {
            return allTasks.value.orEmpty()
        } else {
            return allTasks.value?.filter { task ->
                task.title.contains(query, ignoreCase = true)
            } ?: emptyList()
        }
        _filteredTasks.value = filteredList
    }

    fun addTask(newSch: Schedule) {
        scheduleRepository.addSchedule(newSch)
    }

    fun filterPri(): List<Schedule> {
        return allTasks.value
            ?.filter { it.isPriority }
            ?: emptyList()
    }
}


