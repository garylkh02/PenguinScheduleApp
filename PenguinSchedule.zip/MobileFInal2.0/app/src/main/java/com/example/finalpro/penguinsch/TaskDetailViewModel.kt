package com.example.finalpro.penguinsch

import TaskDetailViewModelFactory
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import java.util.*

class TaskDetailViewModel(private val scheduleRepository: ScheduleRepository) : ViewModel() {

    private val scheduleIdLiveData = MutableLiveData<UUID>()

    val scheduleLiveData: LiveData<Schedule?> = Transformations.switchMap(scheduleIdLiveData) { taskId ->
        scheduleRepository.getTask(taskId)
    }

    fun loadSchedule(taskId: UUID) {
        scheduleIdLiveData.value = taskId
    }

    fun saveSchedule(saveTask: Schedule) {
        scheduleRepository.updateSchedule(saveTask)
    }

    fun markAsPriority(taskId: UUID, isPriority: Boolean) {
        scheduleRepository.setPriority(taskId, isPriority)
    }

    fun updatePartnerName(scheduleId: UUID, partnerName: String) {
        scheduleRepository.updatePartnerName(scheduleId, partnerName)
    }

    companion object {
        fun create(activity: FragmentActivity, scheduleRepository: ScheduleRepository): TaskDetailViewModel {
            return ViewModelProvider(activity, TaskDetailViewModelFactory(scheduleRepository))
                .get(TaskDetailViewModel::class.java)
        }
    }
}
