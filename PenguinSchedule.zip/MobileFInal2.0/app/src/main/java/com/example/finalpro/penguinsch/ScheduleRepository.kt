package com.example.finalpro.penguinsch
import android.content.Context
import androidx.lifecycle.LiveData
import androidx.room.Room
import com.example.finalpro.penguinsch.database.TaskDao
import com.example.finalpro.penguinsch.database.ScheduleDatabase
import com.example.finalpro.penguinsch.database.migration_1_2
import java.lang.IllegalStateException
import java.util.*
import java.util.concurrent.Executor
import java.util.concurrent.Executors

private const val DATABASE_NAME = "schedule-database"

class ScheduleRepository private constructor(context: Context) {
    private val database: ScheduleDatabase =
        Room.databaseBuilder(context.applicationContext, ScheduleDatabase::class.java, DATABASE_NAME)
            .addMigrations(migration_1_2)
            .build()
    private val taskDao: TaskDao = database.taskDao()

    private val executor: Executor = Executors.newSingleThreadExecutor()

    fun getSchedules(): LiveData<List<Schedule>> = taskDao.getTasks()

    fun getTask(id: UUID): LiveData<Schedule?> = taskDao.getTask(id)

    fun updatePartnerName(taskId: UUID, partnerName: String) {
        executor.execute {
            taskDao.updatePartnerName(taskId, partnerName)
        }
    }

    fun updateSchedule(updateTask: Schedule) {
        executor.execute {
            taskDao.updateSchedule(updateTask)
        }
    }

    fun addSchedule(newTask: Schedule) {
        executor.execute {
            taskDao.addSchedule(newTask)
        }
    }

    fun deleteSchedule(schedule: Schedule) {
        executor.execute {
            taskDao.deleteSchedule(schedule)
        }
    }

    fun setPriority(taskId: UUID, isPriority: Boolean) {
        executor.execute {
            taskDao.setPriority(taskId, isPriority)
        }
    }

    companion object {
        private var INSTANCE: ScheduleRepository? = null
        fun initialize(context: Context) {
            if (INSTANCE == null) {
                INSTANCE = ScheduleRepository(context)
            }
        }

        fun get(): ScheduleRepository {
            return INSTANCE ?: throw IllegalStateException("ScheduleRepository must be initialized")
        }


    }

}

