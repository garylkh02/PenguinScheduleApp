package com.example.finalpro.penguinsch.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import androidx.room.Delete
import com.example.finalpro.penguinsch.Schedule
import java.util.*

@Dao
interface TaskDao {
    @Query("SELECT * FROM schedule")
    fun getTasks(): LiveData<List<Schedule>>

    @Query("SELECT * FROM schedule WHERE id=(:id)")
    fun getTask(id: UUID): LiveData<Schedule?>

    @Query("SELECT partner FROM schedule WHERE id=:id")
    fun getPartnerName(id: UUID): LiveData<String?>

    @Query("UPDATE schedule SET partner=:partnerName WHERE id=:id")
    fun updatePartnerName(id: UUID, partnerName: String)

    @Query("UPDATE schedule SET isPriority = :isPriority WHERE id = :id")
    fun setPriority(id: UUID, isPriority: Boolean)

    @Query("SELECT * FROM schedule WHERE isPriority = 1")
    fun getPriorityTasks(): LiveData<List<Schedule>>

    @Query("UPDATE schedule SET description = :description WHERE id = :id")
    fun updateDescription(id: UUID, description: String)

    @Update
    fun updateSchedule(task: Schedule)

    @Insert
    fun addSchedule(task: Schedule)

    @Delete
    fun deleteSchedule(schedule: Schedule)
}