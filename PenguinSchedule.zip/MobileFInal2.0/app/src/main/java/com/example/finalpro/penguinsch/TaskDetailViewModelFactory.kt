import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.finalpro.penguinsch.ScheduleRepository
import com.example.finalpro.penguinsch.TaskDetailViewModel

class TaskDetailViewModelFactory(private val scheduleRepository: ScheduleRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TaskDetailViewModel::class.java)) {
            return TaskDetailViewModel(scheduleRepository) as T
        }

        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
