package com.example.finalpro.penguinsch

import android.content.Context
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.widget.SearchView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.*

private const val TAG = "ScheduleListFragment"

private const val PRIORITY_ITEM_ID = R.id.view_priorities

class ScheduleListFragment : Fragment() {
    interface Callbacks {
        fun onTaskSelected(taskId: UUID);
    }

    private var priorityButtonOriginalIcon: Drawable? = null
    private var isPriorityListShown = false
    private var callbacks: Callbacks? = null
    private var priorityMenuItem: MenuItem? = null

    private val scheduleListViewModel: ScheduleListViewModel by lazy {
        ViewModelProviders.of(this).get(ScheduleListViewModel::class.java)
    }

    private lateinit var taskRecyclerView: RecyclerView;

    private var adapter: TaskAdapter? = TaskAdapter(emptyList())

    override fun onAttach(context: Context) {
        super.onAttach(context)
        callbacks = context as Callbacks?
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_schedule_list, container, false)
        taskRecyclerView = view.findViewById(R.id.schedule_recycler_view) as RecyclerView
        taskRecyclerView.layoutManager = LinearLayoutManager(context)
        taskRecyclerView.adapter = adapter
        return view
    }

    override fun onPrepareOptionsMenu(menu: Menu) {
        super.onPrepareOptionsMenu(menu)

        val isPriorityItemShown = isPriorityListShown

        if (isPriorityItemShown) {
            isPriorityListShown = false
            priorityMenuItem?.icon = priorityButtonOriginalIcon
        }

        val priorityItem = menu.findItem(PRIORITY_ITEM_ID)
        priorityItem.isEnabled = !isPriorityItemShown
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        scheduleListViewModel.taskListLiveData.observe(
            viewLifecycleOwner,
            Observer { tasks ->
                tasks?.let { Log.i(TAG, "Got tasks ${tasks.size}") }
                updateUI(tasks)
            })

        scheduleListViewModel.filteredTasks.observe(viewLifecycleOwner, Observer { tasks ->
            tasks?.let { Log.i(TAG, "Got tasks ${tasks.size}") }
            updateUI(tasks)
        })

    }

    override fun onDetach() {
        super.onDetach()
        callbacks = null
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        inflater.inflate(R.menu.fragment_schedule_list, menu)

        val searchItem = menu.findItem(R.id.search_action)
        val searchView = searchItem?.actionView as SearchView

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                scheduleListViewModel.filterTasks(query)
                isPriorityListShown = false
                return true
            }

            override fun onQueryTextChange(newText: String): Boolean {
                val searchData = scheduleListViewModel.filterTasks(newText)
                updateUI(searchData)
                isPriorityListShown = false
                return true
            }
        })

        priorityMenuItem = menu.findItem(R.id.view_priorities)

        priorityButtonOriginalIcon = priorityMenuItem?.icon
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.new_event -> {
                val selectTask = Schedule()
                scheduleListViewModel.addTask(selectTask)
                callbacks?.onTaskSelected(selectTask.id)
                true
            }
            R.id.view_priorities -> {
                isPriorityListShown = !isPriorityListShown

                if (isPriorityListShown) {
                    val priorityTasks = scheduleListViewModel.filterPri()
                    updateUI(priorityTasks)
                    priorityMenuItem?.icon = ContextCompat.getDrawable(requireContext(), R.drawable.baseline_stars_24)
                } else {
                    val allTasks = scheduleListViewModel.allTasks.value
                        ?: emptyList()
                    updateUI(allTasks)
                    priorityMenuItem?.icon = priorityButtonOriginalIcon
                }

                true
            }

            else ->
            {
                super.onOptionsItemSelected(item)
                isPriorityListShown = false
                priorityMenuItem?.icon = priorityButtonOriginalIcon
                true
            }
        }
    }

    private fun updateUI(taskUi: List<Schedule>) {
        adapter = TaskAdapter(taskUi)
        taskRecyclerView.adapter = adapter
    }

    companion object {
        fun newInstance(): ScheduleListFragment {
            return ScheduleListFragment()
        }
    }

    private inner class TaskHolder(view: View) : RecyclerView.ViewHolder(view), View.OnClickListener {
        private val titleTextView: TextView = itemView.findViewById(R.id.event_title) as TextView
        private val dateTextView: TextView = itemView.findViewById(R.id.deadline_date) as TextView
        private val solvedImageView: ImageView = itemView.findViewById(R.id.task_completed) as ImageView
        private lateinit var scheduless: Schedule

        init {
            itemView.setOnClickListener(this)
        }

        fun bind(bindTaskDet: Schedule) {
            this.scheduless = bindTaskDet
            titleTextView.text = bindTaskDet.title
            dateTextView.text = bindTaskDet.date.toString()
            solvedImageView.visibility = if (bindTaskDet.isSolved) {
                View.VISIBLE
            } else {
                View.GONE
            }

        }

        /**
         * Called when a view has been clicked.
         *
         * @param v The view that was clicked.
         */
        override fun onClick(v: View?) {
            callbacks?.onTaskSelected(scheduless.id)
        }
    }

    private inner class TaskAdapter(var holdTasks: List<Schedule>) :
        RecyclerView.Adapter<TaskHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskHolder {
            val view = layoutInflater.inflate(R.layout.list_schedule, parent, false)
            return TaskHolder(view)
        }

        override fun onBindViewHolder(holder: TaskHolder, position: Int) {
            val bindTasks = holdTasks[position]
            holder.bind(bindTasks)
        }

        override fun getItemCount(): Int = holdTasks.size

    }
}