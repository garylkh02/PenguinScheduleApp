package com.example.finalpro.penguinsch

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView


class PrioFragment : Fragment() {

    private val scheduleRepository: ScheduleRepository by lazy {
        ScheduleRepository.get()
    }

    private lateinit var priorityRecyclerView: RecyclerView
    private var adapter: TaskAdapter? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_prio, container, false)
        priorityRecyclerView = view.findViewById(R.id.prio_recycler_view) as RecyclerView
        priorityRecyclerView.layoutManager = LinearLayoutManager(context)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = TaskAdapter()

        priorityRecyclerView.adapter = adapter

        scheduleRepository.getSchedules().observe(viewLifecycleOwner, Observer { tasks ->
            tasks?.let {
                val priorityTasks = tasks.filter { task -> task.isPriority }
                updateUI(priorityTasks)
            }
        })
    }

    private fun updateUI(priorityTasks: List<Schedule>) {
        adapter?.submitList(priorityTasks)
    }

    private inner class TaskHolder(view: View) : RecyclerView.ViewHolder(view) {
    }

    private inner class TaskAdapter :
        ListAdapter<Schedule, TaskHolder>(ScheduleDiffCallback()) {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskHolder {
            val view = layoutInflater.inflate(R.layout.list_schedule, parent, false)
            return TaskHolder(view)
        }

        override fun onBindViewHolder(holder: TaskHolder, position: Int) {
            val schedule = getItem(position)
        }
    }

    private class ScheduleDiffCallback : DiffUtil.ItemCallback<Schedule>() {
        override fun areItemsTheSame(oldItem: Schedule, newItem: Schedule): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Schedule, newItem: Schedule): Boolean {
            return oldItem.title == newItem.title &&
                    oldItem.date == newItem.date &&
                    oldItem.isSolved == newItem.isSolved &&
                    oldItem.partner == newItem.partner
        }
    }


}

