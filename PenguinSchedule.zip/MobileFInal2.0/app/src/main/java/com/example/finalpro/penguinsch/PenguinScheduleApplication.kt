package com.example.finalpro.penguinsch

import android.app.Application

class PenguinScheduleApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        ScheduleRepository.initialize(this)
    }
}
