package com.example.finalpro.penguinsch

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.text.Editable
import android.text.TextWatcher
import android.text.format.DateFormat
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.android.material.snackbar.Snackbar
import androidx.navigation.fragment.findNavController
import java.util.*

private const val ARG_TASK_ID = "task_id"
private const val DIALOG_DATE = "DialogDate"
private const val REQUEST_DATE = 0
private const val REQUEST_CONTACT = 1
private const val REQUEST_PHONE = 2
private const val DATE_FORMAT = "EEE, MM, dd"


class ScheduleFragment : Fragment(), DatePickerFragment.Callbacks{
    private lateinit var taskFrag: Schedule
    private lateinit var titleField: EditText
    private lateinit var dateButton: Button
    private lateinit var completedCheckBox: CheckBox
    private lateinit var shareButton: Button
    private lateinit var partnerButton: Button
    private lateinit var deleteButton: Button
    private lateinit var priorityButton: ImageButton
    private lateinit var saveButton: Button
    private lateinit var descriptionEditText: EditText

    private var storedDescription: String? = null

    override fun onDateTimeSelected(date: Date) {
        taskFrag.date = date
        storedDescription = descriptionEditText.text.toString()
        updateUI()
        descriptionEditText.setText(storedDescription)
    }


    private val scheduleRepository: ScheduleRepository by lazy {
        ScheduleRepository.get()
    }

    private val taskDetailViewModel: TaskDetailViewModel by lazy {
        TaskDetailViewModel.create(requireActivity(), scheduleRepository)
    }

    private var selectedPartnerName: String? = null


    companion object {
        fun newInstance(taskId: UUID): ScheduleFragment {
            val args = Bundle().apply {
                putSerializable(ARG_TASK_ID, taskId)
            }
            return ScheduleFragment().apply {
                arguments = args
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        taskFrag = Schedule()
        val taskId: UUID = arguments?.getSerializable(ARG_TASK_ID) as UUID
        taskDetailViewModel.loadSchedule(taskId)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_schedule, container, false)
        titleField = view.findViewById(R.id.event_title) as EditText
        dateButton = view.findViewById(R.id.deadline_date) as Button
        completedCheckBox = view.findViewById(R.id.task_completed) as CheckBox
        shareButton = view.findViewById(R.id.share_event) as Button
        partnerButton = view.findViewById(R.id.partner) as Button
        deleteButton = view.findViewById(R.id.delete_button) as Button
        priorityButton = view.findViewById(R.id.priorityy_button) as ImageButton
        saveButton = view.findViewById(R.id.save_button) as Button
        descriptionEditText = view.findViewById(R.id.description_edit_text) as EditText

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        deleteButton.setOnClickListener {
            showDeleteConfirmationDialog()
        }

        taskDetailViewModel.scheduleLiveData.observe(
            viewLifecycleOwner
        ) { viewTask ->
            viewTask?.let {
                this.taskFrag = viewTask
                updateUI()

                updatePriorityButtonIcon(viewTask.isPriority)
            }
        }

        saveButton.setOnClickListener {
            taskFrag.title = titleField.text.toString()
            taskFrag.description = descriptionEditText.text.toString()
            taskFrag.isSolved = completedCheckBox.isChecked
            taskDetailViewModel.saveSchedule(taskFrag)
            showSaveSuccessMessage()
            backHome()
        }


        priorityButton.setOnClickListener {
            val currentSchedule = taskFrag
            storedDescription = descriptionEditText.text.toString()
            currentSchedule.isPriority = !currentSchedule.isPriority
            taskDetailViewModel.saveSchedule(currentSchedule)
            updatePriorityButtonIcon(currentSchedule.isPriority)
            taskDetailViewModel.markAsPriority(currentSchedule.id, currentSchedule.isPriority)
            updateUI()
            descriptionEditText.setText(storedDescription)
        }
    }

    private fun backHome(){
        val intent = Intent(requireActivity(), MainActivity::class.java)
        startActivity(intent)
    }

    private fun showSaveSuccessMessage() {
        Toast.makeText(requireContext(), "Task saved successfully!", Toast.LENGTH_SHORT).show()
    }

    private fun showDeletedSuccessMessage() {
        Snackbar.make(requireView(), "Task deleted successfully!", Snackbar.LENGTH_SHORT).show()
    }


    private fun updatePriorityButtonIcon(isPriority: Boolean) {
        if (isPriority) {
            priorityButton.setImageResource(R.drawable.ic_prioritised)
        } else {
            priorityButton.setImageResource(R.drawable.ic_priority)
        }
    }

    private fun showDeleteConfirmationDialog() {
        val confirmationDialog = AlertDialog.Builder(requireContext())
            .setTitle("Delete Task")
            .setMessage("Are you sure you want to delete this task?")
            .setPositiveButton("Delete") { _, _ ->
                deleteTask()
            }
            .setNegativeButton("Cancel", null)
            .create()
        confirmationDialog.show()
    }


    private fun updateUI() {
        titleField.setText(taskFrag.title)
        dateButton.text = taskFrag.date.toString()
        descriptionEditText.setText(taskFrag.description)
        completedCheckBox.apply {
            isChecked = taskFrag.isSolved
            jumpDrawablesToCurrentState()
        }

        if (!storedDescription.isNullOrEmpty()) {
            descriptionEditText.setText(storedDescription)
        }

        updatePriorityButtonIcon(taskFrag.isPriority)

        if (taskFrag.partner.isNotEmpty()) {
            partnerButton.text = taskFrag.partner
        }

        selectedPartnerName?.let {
            partnerButton.text = it
        }
    }

    private fun getTaskOverview(): String {
        val solvedString = if (taskFrag.isSolved) {
            getString(R.string.event_completed)
        } else {
            getString(R.string.event_pending)
        }
        val dateString = DateFormat.format(DATE_FORMAT, taskFrag.date).toString()
        val friendAvai = if (taskFrag.partner.isBlank()) {
            getString(R.string.event_no_friend)
        } else {
            getString(R.string.event_friend, taskFrag.partner)
        }
        return getString(R.string.share_event, taskFrag.title, dateString, solvedString, friendAvai)
    }

    private fun showDatePickerDialog() {
        DatePickerFragment.newInstance(taskFrag.date).apply {
            setTargetFragment(this@ScheduleFragment, REQUEST_DATE)
            show(this@ScheduleFragment.requireFragmentManager(), DIALOG_DATE)
        }
    }

    private fun deleteTask() {
        val scheduleRepository = ScheduleRepository.get()
        scheduleRepository.deleteSchedule(taskFrag)
        showDeletedSuccessMessage()
        requireActivity().onBackPressed()
    }


    override fun onStart() {
        super.onStart()
        val titleWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(
                sequence: CharSequence?,
                start: Int,
                before: Int,
                count: Int
            ) {
                taskFrag.title = sequence.toString()
            }

            override fun afterTextChanged(s: Editable?) {

            }
        }

        titleField.addTextChangedListener(titleWatcher)

        completedCheckBox.apply {
            setOnCheckedChangeListener { _, isChecked -> taskFrag.isSolved = isChecked }
        }

        dateButton.setOnClickListener {
            showDatePickerDialog()
        }

        shareButton.setOnClickListener {
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, getTaskOverview())
                putExtra(Intent.EXTRA_SUBJECT, getString(R.string.event_overview))
            }.also { intent ->
                val chooserIntent = Intent.createChooser(intent, getString(R.string.send_overview))
                startActivity(chooserIntent)
            }
        }

        partnerButton.apply {
            val pickContactIntent =
                Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI)
            setOnClickListener {
                startActivityForResult(pickContactIntent, REQUEST_CONTACT)
            }

            val packageManager: PackageManager = requireActivity().packageManager
            val resolvedActivity: ResolveInfo? =
                packageManager.resolveActivity(pickContactIntent, PackageManager.MATCH_DEFAULT_ONLY)

            Log.d("partnerButton", resolvedActivity.toString())
            if (resolvedActivity == null) {
                isEnabled = false
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_PHONE -> {
                if ((grantResults.isNotEmpty() &&
                            grantResults[0] == PackageManager.PERMISSION_GRANTED)
                ) {
                    val pickPhoneIntent =
                        Intent(
                            Intent.ACTION_PICK
                        ).apply {
                            type = ContactsContract.CommonDataKinds.Phone.CONTENT_TYPE
                        }
                    startActivityForResult(pickPhoneIntent, REQUEST_PHONE)

                } else {
                    Log.e("ScdFragment", "Unavailable permissions CONTACTS")
                }
                return
            }
            else -> {
            }
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when {
            resultCode != Activity.RESULT_OK -> return
            requestCode == REQUEST_CONTACT && data != null -> {
                val contactUri: Uri? = data.data
                val queries = arrayOf(ContactsContract.Contacts.DISPLAY_NAME)
                val cursor = requireActivity().contentResolver.query(
                    contactUri!!,
                    queries,
                    null,
                    null,
                    null
                )

                cursor?.use { it ->
                    if (it.count == 0) {
                        return
                    }

                    it.moveToFirst()
                    val partnerIndex = cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME)
                    val partnerName = it.getString(partnerIndex)

                    selectedPartnerName = partnerName

                    taskDetailViewModel.updatePartnerName(taskFrag.id, partnerName)

                    partnerButton.text = selectedPartnerName
                }
            }
        }
    }








}